<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Order Detail</title>
<base href="${pageContext.request.contextPath}/">
<link href="${pageContext.request.contextPath}/css/bootstrap.min.css"
	rel="stylesheet">
<link href="${pageContext.request.contextPath}/css/style.css"
	rel="stylesheet">
</head>
<body>
	<div class="container py-5">
		<h1>Order Detail</h1>
		<p>Chi tiết đơn hàng admin sẽ hiển thị ở đây.</p>
		<p>
			<a href="${pageContext.request.contextPath}/admin/orders">Quay
				lại đơn hàng</a>
		</p>
	</div>
</body>
</html>
