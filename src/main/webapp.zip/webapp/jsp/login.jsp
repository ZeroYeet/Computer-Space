<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Login | Computer Space</title>
<base href="${pageContext.request.contextPath}/">
<link href="${pageContext.request.contextPath}/css/bootstrap.min.css"
	rel="stylesheet">
<link href="${pageContext.request.contextPath}/css/style.css"
	rel="stylesheet">
</head>
<body>
	<div class="container py-5">
		<h1>Login</h1>
		<form action="${pageContext.request.contextPath}/login" method="post">
			<div class="mb-3">
				<label class="form-label">Tài khoản</label> <input type="text"
					name="username" class="form-control" required>
			</div>
			<div class="mb-3">
				<label class="form-label">Mật khẩu</label> <input type="password"
					name="password" class="form-control" required>
			</div>
			<button type="submit" class="btn btn-primary">Đăng nhập</button>
		</form>
		<p class="mt-3">
			Chưa có tài khoản? <a
				href="${pageContext.request.contextPath}/register">Đăng ký</a>
		</p>
		<p>
			<a href="${pageContext.request.contextPath}/forgot-password">Quên
				mật khẩu</a>
		</p>
		<p>
			<a href="${pageContext.request.contextPath}/home">Về trang chủ</a>
		</p>
	</div>
</body>
</html>
