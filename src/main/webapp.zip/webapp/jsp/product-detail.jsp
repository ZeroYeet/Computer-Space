<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="utf-8">
<title>Electro - Electronics Website Template</title>
<meta content="width=device-width, initial-scale=1.0" name="viewport">
<meta content="" name="keywords">
<meta content="" name="description">
<base href="${pageContext.request.contextPath}/">

<!-- Google Web Fonts -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link
	href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;500;600;700&family=Roboto:wght@400;500;700&display=swap"
	rel="stylesheet">

<!-- Icon Font Stylesheet -->
<link rel="stylesheet"
	href="https://use.fontawesome.com/releases/v5.15.4/css/all.css" />
<link
	href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css"
	rel="stylesheet">

<!-- Libraries Stylesheet -->
<link
	href="${pageContext.request.contextPath}/lib/animate/animate.min.css"
	rel="stylesheet">
<link
	href="${pageContext.request.contextPath}/lib/owlcarousel/assets/owl.carousel.min.css"
	rel="stylesheet">
<link
	href="${pageContext.request.contextPath}/lib/lightbox/css/lightbox.min.css"
	rel="stylesheet">


<!-- Customized Bootstrap Stylesheet -->
<link href="${pageContext.request.contextPath}/css/bootstrap.min.css"
	rel="stylesheet">

<!-- Template Stylesheet -->
<link href="${pageContext.request.contextPath}/css/style.css"
	rel="stylesheet">
</head>

<body>

	<!-- Spinner Start -->
	<div id="spinner"
		class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
		<div class="spinner-border text-primary"
			style="width: 3rem; height: 3rem;" role="status">
			<span class="sr-only">Loading...</span>
		</div>
	</div>
	<!-- Spinner End -->


	<!-- Topbar Start -->
	<div class="container-fluid px-5 d-none border-bottom d-lg-block">
		<div class="row gx-0 align-items-center">
			<div class="col-lg-4 text-center text-lg-start mb-lg-0">
				<div class="d-inline-flex align-items-center" style="height: 45px;">
					<a href="#" class="text-muted me-2"> Help</a><small> / </small> <a
						href="#" class="text-muted mx-2"> Support</a><small> / </small> <a
						href="#" class="text-muted ms-2"> Contact</a>
				</div>
			</div>
			<div
				class="col-lg-4 text-center d-flex align-items-center justify-content-center">
				<small class="text-dark">Call Us:</small> <a href="#"
					class="text-muted">(+012) 1234 567890</a>
			</div>

			<div class="col-lg-4 text-center text-lg-end">
				<div class="d-inline-flex align-items-center" style="height: 45px;">
					<div class="dropdown">
						<a href="#" class="dropdown-toggle text-muted me-2"
							data-bs-toggle="dropdown"><small> USD</small></a>
						<div class="dropdown-menu rounded">
							<a href="#" class="dropdown-item"> Euro</a> <a href="#"
								class="dropdown-item"> Dolar</a>
						</div>
					</div>
					<div class="dropdown">
						<a href="#" class="dropdown-toggle text-muted mx-2"
							data-bs-toggle="dropdown"><small> English</small></a>
						<div class="dropdown-menu rounded">
							<a href="#" class="dropdown-item"> English</a> <a href="#"
								class="dropdown-item"> Turkish</a> <a href="#"
								class="dropdown-item"> Spanol</a> <a href="#"
								class="dropdown-item"> Italiano</a>
						</div>
					</div>
					<div class="dropdown">
						<a href="#" class="dropdown-toggle text-muted ms-2"
							data-bs-toggle="dropdown"><small><i
								class="fa fa-home me-2"></i> My Dashboard</small></a>
						<div class="dropdown-menu rounded">
							<a href="#" class="dropdown-item"> Login</a> <a href="#"
								class="dropdown-item"> Wishlist</a> <a href="#"
								class="dropdown-item"> My Card</a> <a href="#"
								class="dropdown-item"> Notifications</a> <a href="#"
								class="dropdown-item"> Account Settings</a> <a href="#"
								class="dropdown-item"> My Account</a> <a href="#"
								class="dropdown-item"> Log Out</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="container-fluid px-5 py-4 d-none d-lg-block">
		<div class="row gx-0 align-items-center text-center">
			<div class="col-md-4 col-lg-3 text-center text-lg-start">
				<div class="d-inline-flex align-items-center">
					<a href="" class="navbar-brand p-0">
						<h1 class="display-5 text-primary m-0">
							<i class="fas fa-shopping-bag text-secondary me-2"></i>Electro
						</h1> <!-- <img src="${pageContext.request.contextPath}/img/logo.png" alt="Logo"> -->
					</a>
				</div>
			</div>
			<div class="col-md-4 col-lg-6 text-center">
				<div class="position-relative ps-4">
					<div class="d-flex border rounded-pill">
						<input class="form-control border-0 rounded-pill w-100 py-3"
							type="text" data-bs-target="#dropdownToggle123"
							placeholder="Search Looking For?"> <select
							class="form-select text-dark border-0 border-start rounded-0 p-3"
							style="width: 200px;">
							<option value="All Category">All Category</option>
							<option value="Pest Control-2">Category 1</option>
							<option value="Pest Control-3">Category 2</option>
							<option value="Pest Control-4">Category 3</option>
							<option value="Pest Control-5">Category 4</option>
						</select>
						<button type="button"
							class="btn btn-primary rounded-pill py-3 px-5" style="border: 0;">
							<i class="fas fa-search"></i>
						</button>
					</div>
				</div>
			</div>
			<div class="col-md-4 col-lg-3 text-center text-lg-end">
				<div class="d-inline-flex align-items-center">
					<a href="#"
						class="text-muted d-flex align-items-center justify-content-center me-3"><span
						class="rounded-circle btn-md-square border"><i
							class="fas fa-random"></i></i></a> <a href="#"
						class="text-muted d-flex align-items-center justify-content-center me-3"><span
						class="rounded-circle btn-md-square border"><i
							class="fas fa-heart"></i></a> <a href="#"
						class="text-muted d-flex align-items-center justify-content-center"><span
						class="rounded-circle btn-md-square border"><i
							class="fas fa-shopping-cart"></i></span> <span class="text-dark ms-2">$0.00</span></a>
				</div>
			</div>
		</div>
	</div>
	<!-- Topbar End -->

	<!-- Navbar & Hero Start -->
	<div class="container-fluid nav-bar p-0">
		<div class="row gx-0 bg-primary px-5 align-items-center">
			<div class="col-lg-3 d-none d-lg-block">
				<nav class="navbar navbar-light position-relative"
					style="width: 250px;">
					<button class="navbar-toggler border-0 fs-4 w-100 px-0 text-start"
						type="button" data-bs-toggle="collapse" data-bs-target="#allCat">
						<h4 class="m-0">
							<i class="fa fa-bars me-2"></i>All Categories
						</h4>
					</button>
					<div class="collapse navbar-collapse rounded-bottom" id="allCat">
						<div class="navbar-nav ms-auto py-0">
							<ul class="list-unstyled categories-bars">
								<li>
									<div class="categories-bars-item">
										<a href="#">Accessories</a> <span>(3)</span>
									</div>
								</li>
								<li>
									<div class="categories-bars-item">
										<a href="#">Electronics & Computer</a> <span>(5)</span>
									</div>
								</li>
								<li>
									<div class="categories-bars-item">
										<a href="#">Laptops & Desktops</a> <span>(2)</span>
									</div>
								</li>
								<li>
									<div class="categories-bars-item">
										<a href="#">Mobiles & Tablets</a> <span>(8)</span>
									</div>
								</li>
								<li>
									<div class="categories-bars-item">
										<a href="#">SmartPhone & Smart TV</a> <span>(5)</span>
									</div>
								</li>
							</ul>
						</div>
					</div>
				</nav>
			</div>
			<div class="col-12 col-lg-9">
				<nav class="navbar navbar-expand-lg navbar-light bg-primary ">
					<a href="" class="navbar-brand d-block d-lg-none">
						<h1 class="display-5 text-secondary m-0">
							<i class="fas fa-shopping-bag text-white me-2"></i>Electro
						</h1> <!-- <img src="${pageContext.request.contextPath}/img/logo.png" alt="Logo"> -->
					</a>
					<button class="navbar-toggler ms-auto" type="button"
						data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
						<span class="fa fa-bars fa-1x"></span>
					</button>
					<div class="collapse navbar-collapse" id="navbarCollapse">
						<div class="navbar-nav ms-auto py-0">
							<a href="${pageContext.request.contextPath}/home"
								class="nav-item nav-link">Home</a> <a
								href="${pageContext.request.contextPath}/products"
								class="nav-item nav-link">Shop</a> <a
								href="${pageContext.request.contextPath}/product?id=1"
								class="nav-item nav-link active">Single Page</a>
							<div class="nav-item dropdown">
								<a href="#" class="nav-link" data-bs-toggle="dropdown"><span
									class="dropdown-toggle">Pages</span></a>
								<div class="dropdown-menu m-0">
									<a href="${pageContext.request.contextPath}/promotions"
										class="dropdown-item">Bestseller</a> <a
										href="${pageContext.request.contextPath}/cart"
										class="dropdown-item">Cart Page</a> <a
										href="${pageContext.request.contextPath}/checkout"
										class="dropdown-item">Cheackout</a> <a
										href="${pageContext.request.contextPath}/404.jsp"
										class="dropdown-item">404 Page</a>
								</div>
							</div>
							<a href="${pageContext.request.contextPath}/contact"
								class="nav-item nav-link me-2">Contact</a>
							<div class="nav-item dropdown d-block d-lg-none mb-3">
								<a href="#" class="nav-link" data-bs-toggle="dropdown"><span
									class="dropdown-toggle">All Category</span></a>
								<div class="dropdown-menu m-0">
									<ul class="list-unstyled categories-bars">
										<li>
											<div class="categories-bars-item">
												<a href="#">Accessories</a> <span>(3)</span>
											</div>
										</li>
										<li>
											<div class="categories-bars-item">
												<a href="#">Electronics & Computer</a> <span>(5)</span>
											</div>
										</li>
										<li>
											<div class="categories-bars-item">
												<a href="#">Laptops & Desktops</a> <span>(2)</span>
											</div>
										</li>
										<li>
											<div class="categories-bars-item">
												<a href="#">Mobiles & Tablets</a> <span>(8)</span>
											</div>
										</li>
										<li>
											<div class="categories-bars-item">
												<a href="#">SmartPhone & Smart TV</a> <span>(5)</span>
											</div>
										</li>
									</ul>
								</div>
							</div>
						</div>
						<a href=""
							class="btn btn-secondary rounded-pill py-2 px-4 px-lg-3 mb-3 mb-md-3 mb-lg-0"><i
							class="fa fa-mobile-alt me-2"></i> +0123 456 7890</a>
					</div>
				</nav>
			</div>
		</div>
	</div>
	<!-- Navbar & Hero End -->

	<!-- Single Page Header start -->
	<div class="container-fluid page-header py-5">
		<h1 class="text-center text-white display-6 wow fadeInUp"
			data-wow-delay="0.1s">Single Product</h1>
		<ol class="breadcrumb justify-content-center mb-0 wow fadeInUp"
			data-wow-delay="0.3s">
			<li class="breadcrumb-item"><a href="#">Home</a></li>
			<li class="breadcrumb-item"><a href="#">Pages</a></li>
			<li class="breadcrumb-item active text-white">Single Product</li>
		</ol>
	</div>
	<!-- Single Page Header End -->


	<!-- Single Products Start -->
	<div class="container-fluid shop py-5">
		<div class="container py-5">
			<div class="row g-4">
				<div class="col-lg-5 col-xl-3 wow fadeInUp" data-wow-delay="0.1s">
					<div class="input-group w-100 mx-auto d-flex mb-4">
						<input type="search" class="form-control p-3"
							placeholder="keywords" aria-describedby="search-icon-1">
						<span id="search-icon-1" class="input-group-text p-3"><i
							class="fa fa-search"></i></span>
					</div>
					<div class="product-categories mb-4">
						<h4>Products Categories</h4>
						<ul class="list-unstyled">
							<li>
								<div class="categories-item">
									<a href="#" class="text-dark"><i
										class="fas fa-apple-alt text-secondary me-2"></i> Accessories</a>
									<span>(3)</span>
								</div>
							</li>
							<li>
								<div class="categories-item">
									<a href="#" class="text-dark"><i
										class="fas fa-apple-alt text-secondary me-2"></i> Electronics
										& Computer</a> <span>(5)</span>
								</div>
							</li>
							<li>
								<div class="categories-item">
									<a href="#" class="text-dark"><i
										class="fas fa-apple-alt text-secondary me-2"></i>Laptops &
										Desktops</a> <span>(2)</span>
								</div>
							</li>
							<li>
								<div class="categories-item">
									<a href="#" class="text-dark"><i
										class="fas fa-apple-alt text-secondary me-2"></i>Mobiles &
										Tablets</a> <span>(8)</span>
								</div>
							</li>
							<li>
								<div class="categories-item">
									<a href="#" class="text-dark"><i
										class="fas fa-apple-alt text-secondary me-2"></i>SmartPhone &
										Smart TV</a> <span>(5)</span>
								</div>
							</li>
						</ul>
					</div>
					<div class="additional-product mb-4">
						<h4>Select By Color</h4>
						<div class="additional-product-item">
							<input type="radio" class="me-2" id="Categories-1"
								name="Categories-1" value="Beverages"> <label
								for="Categories-1" class="text-dark"> Gold</label>
						</div>
						<div class="additional-product-item">
							<input type="radio" class="me-2" id="Categories-2"
								name="Categories-1" value="Beverages"> <label
								for="Categories-2" class="text-dark"> Green</label>
						</div>
						<div class="additional-product-item">
							<input type="radio" class="me-2" id="Categories-3"
								name="Categories-1" value="Beverages"> <label
								for="Categories-3" class="text-dark"> White</label>
						</div>
					</div>
					<div class="featured-product mb-4">
						<h4 class="mb-3">Featured products</h4>
						<div class="featured-product-item">
							<div class="rounded me-4" style="width: 100px; height: 100px;">
								<img src="${pageContext.request.contextPath}/img/product-3.png"
									class="img-fluid rounded" alt="Image">
							</div>
							<div>
								<h6 class="mb-2">SmartPhone</h6>
								<div class="d-flex mb-2">
									<i class="fa fa-star text-secondary"></i> <i
										class="fa fa-star text-secondary"></i> <i
										class="fa fa-star text-secondary"></i> <i
										class="fa fa-star text-secondary"></i> <i class="fa fa-star"></i>
								</div>
								<div class="d-flex mb-2">
									<h5 class="fw-bold me-2">2.99 $</h5>
									<h5 class="text-danger text-decoration-line-through">4.11
										$</h5>
								</div>
							</div>
						</div>
						<div class="featured-product-item">
							<div class="rounded me-4" style="width: 100px; height: 100px;">
								<img src="${pageContext.request.contextPath}/img/product-4.png"
									class="img-fluid rounded" alt="Image">
							</div>
							<div>
								<h6 class="mb-2">Smart Camera</h6>
								<div class="d-flex mb-2">
									<i class="fa fa-star text-secondary"></i> <i
										class="fa fa-star text-secondary"></i> <i
										class="fa fa-star text-secondary"></i> <i
										class="fa fa-star text-secondary"></i> <i class="fa fa-star"></i>
								</div>
								<div class="d-flex mb-2">
									<h5 class="fw-bold me-2">2.99 $</h5>
									<h5 class="text-danger text-decoration-line-through">4.11
										$</h5>
								</div>
							</div>
						</div>
						<div class="featured-product-item">
							<div class="rounded me-4" style="width: 100px; height: 100px;">
								<img src="${pageContext.request.contextPath}/img/product-5.png"
									class="img-fluid rounded" alt="Image">
							</div>
							<div>
								<h6 class="mb-2">Smart Camera</h6>
								<div class="d-flex mb-2">
									<i class="fa fa-star text-secondary"></i> <i
										class="fa fa-star text-secondary"></i> <i
										class="fa fa-star text-secondary"></i> <i
										class="fa fa-star text-secondary"></i> <i class="fa fa-star"></i>
								</div>
								<div class="d-flex mb-2">
									<h5 class="fw-bold me-2">2.99 $</h5>
									<h5 class="text-danger text-decoration-line-through">4.11
										$</h5>
								</div>
							</div>
						</div>
						<div class="featured-product-item">
							<div class="rounded me-4" style="width: 100px; height: 100px;">
								<img src="${pageContext.request.contextPath}/img/product-6.png"
									class="img-fluid rounded" alt="Image">
							</div>
							<div>
								<h6 class="mb-2">Smart Camera</h6>
								<div class="d-flex mb-2">
									<i class="fa fa-star text-secondary"></i> <i
										class="fa fa-star text-secondary"></i> <i
										class="fa fa-star text-secondary"></i> <i
										class="fa fa-star text-secondary"></i> <i class="fa fa-star"></i>
								</div>
								<div class="d-flex mb-2">
									<h5 class="fw-bold me-2">2.99 $</h5>
									<h5 class="text-danger text-decoration-line-through">4.11
										$</h5>
								</div>
							</div>
						</div>
						<div class="featured-product-item">
							<div class="rounded me-4" style="width: 100px; height: 100px;">
								<img src="${pageContext.request.contextPath}/img/product-7.png"
									class="img-fluid rounded" alt="Image">
							</div>
							<div>
								<h6 class="mb-2">Camera Leance</h6>
								<div class="d-flex mb-2">
									<i class="fa fa-star text-secondary"></i> <i
										class="fa fa-star text-secondary"></i> <i
										class="fa fa-star text-secondary"></i> <i
										class="fa fa-star text-secondary"></i> <i class="fa fa-star"></i>
								</div>
								<div class="d-flex mb-2">
									<h5 class="fw-bold me-2">2.99 $</h5>
									<h5 class="text-danger text-decoration-line-through">4.11
										$</h5>
								</div>
							</div>
						</div>
						<div class="featured-product-item">
							<div class="rounded me-4" style="width: 100px; height: 100px;">
								<img src="${pageContext.request.contextPath}/img/product-8.png"
									class="img-fluid rounded" alt="Image">
							</div>
							<div>
								<h6 class="mb-2">Smart Camera</h6>
								<div class="d-flex mb-2">
									<i class="fa fa-star text-secondary"></i> <i
										class="fa fa-star text-secondary"></i> <i
										class="fa fa-star text-secondary"></i> <i
										class="fa fa-star text-secondary"></i> <i class="fa fa-star"></i>
								</div>
								<div class="d-flex mb-2">
									<h5 class="fw-bold me-2">2.99 $</h5>
									<h5 class="text-danger text-decoration-line-through">4.11
										$</h5>
								</div>
							</div>
						</div>
						<div class="d-flex justify-content-center my-4">
							<a href="#" class="btn btn-primary px-4 py-3 rounded-pill w-100">Vew
								More</a>
						</div>
					</div>
					<a href="#">
						<div class="position-relative">
							<img
								src="${pageContext.request.contextPath}/img/product-banner-2.jpg"
								class="img-fluid w-100 rounded" alt="Image">
							<div
								class="text-center position-absolute d-flex flex-column align-items-center justify-content-center rounded p-4"
								style="width: 100%; height: 100%; top: 0; right: 0; background: rgba(242, 139, 0, 0.3);">
								<h5 class="display-6 text-primary">SALE</h5>
								<h4 class="text-secondary">Get UP To 50% Off</h4>
								<a href="#" class="btn btn-primary rounded-pill px-4">Shop
									Now</a>
							</div>
						</div>
					</a>
					<div class="product-tags my-4">
						<h4 class="mb-3">PRODUCT TAGS</h4>
						<div class="product-tags-items bg-light rounded p-3">
							<a href="#" class="border rounded py-1 px-2 mb-2">New</a> <a
								href="#" class="border rounded py-1 px-2 mb-2">brand</a> <a
								href="#" class="border rounded py-1 px-2 mb-2">black</a> <a
								href="#" class="border rounded py-1 px-2 mb-2">white</a> <a
								href="#" class="border rounded py-1 px-2 mb-2">tablats</a> <a
								href="#" class="border rounded py-1 px-2 mb-2">phone</a> <a
								href="#" class="border rounded py-1 px-2 mb-2">camera</a> <a
								href="#" class="border rounded py-1 px-2 mb-2">drone</a> <a
								href="#" class="border rounded py-1 px-2 mb-2">talevision</a> <a
								href="#" class="border rounded py-1 px-2 mb-2">slaes</a>
						</div>
					</div>
				</div>
				<div class="col-lg-7 col-xl-9 wow fadeInUp" data-wow-delay="0.1s">
					<div class="row g-4 single-product">
						<div class="col-xl-6">
							<div class="single-carousel owl-carousel">
								<div class="single-item"
									data-dot="<img class='img-fluid' src='img/product-4.png' alt=''>">
									<div class="single-inner bg-light rounded">
										<img
											src="${pageContext.request.contextPath}/img/product-4.png"
											class="img-fluid rounded" alt="Image">
									</div>
								</div>
								<div class="single-item"
									data-dot="<img class='img-fluid' src='img/product-5.png' alt=''>">
									<div class="single-inner bg-light rounded">
										<img
											src="${pageContext.request.contextPath}/img/product-5.png"
											class="img-fluid rounded" alt="Image">
									</div>
								</div>
								<div class="single-item"
									data-dot="<img class='img-fluid' src='img/product-6.png' alt=''>">
									<div class="single-inner bg-light rounded">
										<img
											src="${pageContext.request.contextPath}/img/product-6.png"
											class="img-fluid rounded" alt="Image">
									</div>
								</div>
								<div class="single-item"
									data-dot="<img class='img-fluid' src='img/product-7.png' alt=''>">
									<div class="single-inner bg-light rounded">
										<img
											src="${pageContext.request.contextPath}/img/product-7.png"
											class="img-fluid rounded" alt="Image">
									</div>
								</div>
								<div class="single-item"
									data-dot="<img class='img-fluid' src='img/product-3.png' alt=''>">
									<div class="single-inner bg-light rounded">
										<img
											src="${pageContext.request.contextPath}/img/product-3.png"
											class="img-fluid rounded" alt="Image">
									</div>
								</div>
							</div>
						</div>
						<div class="col-xl-6">
							<h4 class="fw-bold mb-3">Smart Camera</h4>
							<p class="mb-3">Category: Electronics</p>
							<h5 class="fw-bold mb-3">3,35 $</h5>
							<div class="d-flex mb-4">
								<i class="fa fa-star text-secondary"></i> <i
									class="fa fa-star text-secondary"></i> <i
									class="fa fa-star text-secondary"></i> <i
									class="fa fa-star text-secondary"></i> <i class="fa fa-star"></i>
							</div>
							<div class="mb-3">
								<div
									class="btn btn-primary d-inline-block rounded text-white py-1 px-4 me-2">
									<i class="fab fa-facebook-f me-1"></i> Share
								</div>
								<div
									class="btn btn-secondary d-inline-block rounded text-white py-1 px-4 ms-2">
									<i class="fab fa-twitter ms-1"></i> Share
								</div>
							</div>
							<div class="d-flex flex-column mb-3">
								<small>Product SKU: N/A</small> <small>Available: <strong
									class="text-primary">20 items in stock</strong></small>
							</div>
							<p class="mb-4">The generated Lorem Ipsum is therefore always
								free from repetition injected humour, or non-characteristic
								words etc.</p>
							<p class="mb-4">Susp endisse ultricies nisi vel quam
								suscipit. Sabertooth peacock flounder; chain pickerel
								hatchetfish, pencilfish snailfish</p>
							<div class="input-group quantity mb-5" style="width: 100px;">
								<div class="input-group-btn">
									<button
										class="btn btn-sm btn-minus rounded-circle bg-light border">
										<i class="fa fa-minus"></i>
									</button>
								</div>
								<input type="text"
									class="form-control form-control-sm text-center border-0"
									value="1">
								<div class="input-group-btn">
									<button
										class="btn btn-sm btn-plus rounded-circle bg-light border">
										<i class="fa fa-plus"></i>
									</button>
								</div>
							</div>
							<a href="#"
								class="btn btn-primary border border-secondary rounded-pill px-4 py-2 mb-4 text-primary"><i
								class="fa fa-shopping-bag me-2 text-white"></i> Add to cart</a>
						</div>
						<div class="col-lg-12">
							<nav>
								<div class="nav nav-tabs mb-3">
									<button class="nav-link active border-white border-bottom-0"
										type="button" role="tab" id="nav-about-tab"
										data-bs-toggle="tab" data-bs-target="#nav-about"
										aria-controls="nav-about" aria-selected="true">Description</button>
									<button class="nav-link border-white border-bottom-0"
										type="button" role="tab" id="nav-mission-tab"
										data-bs-toggle="tab" data-bs-target="#nav-mission"
										aria-controls="nav-mission" aria-selected="false">Reviews</button>
								</div>
							</nav>
							<div class="tab-content mb-5">
								<div class="tab-pane active" id="nav-about" role="tabpanel"
									aria-labelledby="nav-about-tab">
									<p>
										Our new <b class="fw-bold">HPB12 / A12 battery</b> is rated at
										2000mAh and designed to power up Black and Decker / FireStorm
										line of 12V tools allowing users to run multiple devices off
										the same battery pack. The HPB12 is compatible with the
										following Black and Decker power tool models:
									</p>
									<b class="fw-bold">Black & Decker Drills and Drivers:</b>
									<p class="small">BD12PSK, BDG1200K, BDGL12K, BDID1202,
										CD1200SK, CD12SFK, CDC1200K, CDC120AK, CDC120ASB, CP122K,
										CP122KB, CP12K, CP12KB, EPC12, EPC126, EPC126BK, EPC12CA,
										EPC12CABK, HP122K, HP122KD, HP126F2B, HP126F2K, HP126F3B,
										HP126F3K, HP126FBH, HP126FSC, HP126FSH, HP126K, HP128F3B,
										HP12K, HP12KD, HPD1200, HPD1202, HPD1202KF, HPD12K-2, PS122K,
										PS122KB, PS12HAK, SS12, SX3000, SX3500, XD1200, XD1200K,
										XTC121</p>
									<b class="fw-bold">lack & Decker Impact Wrenches:</b>
									<p class="small">SX5000, XTC12IK, XTC12IKH</p>
									<b class="fw-bold">Black & Decker Multi-Tools:</b>
									<p class="small">KC2000FK</p>
									<b class="fw-bold">Black & Decker Nailers:</b>
									<p class="small">BDBN1202</p>
									<b class="fw-bold">Black & Decker Screwdrivers:</b>
									<p class="small">HP9019K</p>
									<b class="fw-bold mb-0">Best replacement for the following
										Black and Decker OEM battery part numbers:</b>
									<p class="small">HPB12, A12, A12EX, A12-XJ, A1712, B-8315,
										BD1204L, BD-1204L, BPT1047, FS120B, FS120BX, FSB12.</p>
								</div>
								<div class="tab-pane" id="nav-mission" role="tabpanel"
									aria-labelledby="nav-mission-tab">
									<div class="d-flex">
										<img src="${pageContext.request.contextPath}/img/avatar.jpg"
											class="img-fluid rounded-circle p-3"
											style="width: 100px; height: 100px;" alt="">
										<div class="">
											<p class="mb-2" style="font-size: 14px;">April 12, 2024</p>
											<div class="d-flex justify-content-between">
												<h5>Jason Smith</h5>
												<div class="d-flex mb-3">
													<i class="fa fa-star text-secondary"></i> <i
														class="fa fa-star text-secondary"></i> <i
														class="fa fa-star text-secondary"></i> <i
														class="fa fa-star text-secondary"></i> <i
														class="fa fa-star"></i>
												</div>
											</div>
											<p>The generated Lorem Ipsum is therefore always free
												from repetition injected humour, or non-characteristic words
												etc. Susp endisse ultricies nisi vel quam suscipit</p>
										</div>
									</div>
									<div class="d-flex">
										<img src="${pageContext.request.contextPath}/img/avatar.jpg"
											class="img-fluid rounded-circle p-3"
											style="width: 100px; height: 100px;" alt="">
										<div class="">
											<p class="mb-2" style="font-size: 14px;">April 12, 2024</p>
											<div class="d-flex justify-content-between">
												<h5>Sam Peters</h5>
												<div class="d-flex mb-3">
													<i class="fa fa-star text-secondary"></i> <i
														class="fa fa-star text-secondary"></i> <i
														class="fa fa-star text-secondary"></i> <i
														class="fa fa-star"></i> <i class="fa fa-star"></i>
												</div>
											</div>
											<p class="text-dark">The generated Lorem Ipsum is
												therefore always free from repetition injected humour, or
												non-characteristic words etc. Susp endisse ultricies nisi
												vel quam suscipit</p>
										</div>
									</div>
								</div>
								<div class="tab-pane" id="nav-vision" role="tabpanel">
									<p class="text-dark">Tempor erat elitr rebum at clita. Diam
										dolor diam ipsum et tempor sit. Aliqu diam amet diam et eos
										labore. 3</p>
									<p class="mb-0">Diam dolor diam ipsum et tempor sit. Aliqu
										diam amet diam et eos labore. Clita erat ipsum et lorem et sit</p>
								</div>
							</div>
						</div>
						<form action="#">
							<h4 class="mb-5 fw-bold">Leave a Reply</h4>
							<div class="row g-4">
								<div class="col-lg-6">
									<div class="border-bottom rounded">
										<input type="text" class="form-control border-0 me-4"
											placeholder="Yur Name *">
									</div>
								</div>
								<div class="col-lg-6">
									<div class="border-bottom rounded">
										<input type="email" class="form-control border-0"
											placeholder="Your Email *">
									</div>
								</div>
								<div class="col-lg-12">
									<div class="border-bottom rounded my-4">
										<textarea name="" id="" class="form-control border-0"
											cols="30" rows="8" placeholder="Your Review *"
											spellcheck="false"></textarea>
									</div>
								</div>
								<div class="col-lg-12">
									<div class="d-flex justify-content-between py-3 mb-5">
										<div class="d-flex align-items-center">
											<p class="mb-0 me-3">Please rate:</p>
											<div class="d-flex align-items-center"
												style="font-size: 12px;">
												<i class="fa fa-star text-muted"></i> <i class="fa fa-star"></i>
												<i class="fa fa-star"></i> <i class="fa fa-star"></i> <i
													class="fa fa-star"></i>
											</div>
										</div>
										<a href="#"
											class="btn btn-primary border border-secondary text-primary rounded-pill px-4 py-3">
											Post Comment</a>
									</div>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- Single Products End -->

	<!-- Related Product Start -->
	<div class="container-fluid related-product">
		<div class="container">
			<div class="mx-auto text-center pb-5" style="max-width: 700px;">
				<h4
					class="text-primary mb-4 border-bottom border-primary border-2 d-inline-block p-2 title-border-radius wow fadeInUp"
					data-wow-delay="0.1s">Related Products</h4>
				<p class="wow fadeInUp" data-wow-delay="0.2s">Lorem ipsum dolor
					sit amet consectetur adipisicing elit. Modi, asperiores ducimus
					sint quos tempore officia similique quia? Libero, pariatur
					consectetur?</p>
			</div>
			<div class="related-carousel owl-carousel pt-4">
				<div class="related-item rounded">
					<div class="related-item-inner border rounded">
						<div class="related-item-inner-item">
							<img src="${pageContext.request.contextPath}/img/product-3.png"
								class="img-fluid w-100 rounded-top" alt="">
							<div class="related-new">New</div>
							<div class="related-details">
								<a href="#"><i class="fa fa-eye fa-1x"></i></a>
							</div>
						</div>
						<div class="text-center rounded-bottom p-4">
							<a href="#" class="d-block mb-2">SmartPhone</a> <a href="#"
								class="d-block h4">Apple iPad Mini <br> G2356
							</a>
							<del class="me-2 fs-5">$1,250.00</del>
							<span class="text-primary fs-5">$1,050.00</span>
						</div>
					</div>
					<div
						class="related-item-add border border-top-0 rounded-bottom  text-center p-4 pt-0">
						<a href="#"
							class="btn btn-primary border-secondary rounded-pill py-2 px-4 mb-4"><i
							class="fas fa-shopping-cart me-2"></i> Add To Cart</a>
						<div class="d-flex justify-content-between align-items-center">
							<div class="d-flex">
								<i class="fas fa-star text-primary"></i> <i
									class="fas fa-star text-primary"></i> <i
									class="fas fa-star text-primary"></i> <i
									class="fas fa-star text-primary"></i> <i class="fas fa-star"></i>
							</div>
							<div class="d-flex">
								<a href="#"
									class="text-primary d-flex align-items-center justify-content-center me-3"><span
									class="rounded-circle btn-sm-square border"><i
										class="fas fa-random"></i></i></a> <a href="#"
									class="text-primary d-flex align-items-center justify-content-center me-0"><span
									class="rounded-circle btn-sm-square border"><i
										class="fas fa-heart"></i></a>
							</div>
						</div>
					</div>
				</div>
				<div class="related-item rounded">
					<div class="related-item-inner border rounded">
						<div class="related-item-inner-item">
							<img src="${pageContext.request.contextPath}/img/product-3.png"
								class="img-fluid w-100 rounded-top" alt="">
							<div class="related-new">New</div>
							<div class="related-details">
								<a href="#"><i class="fa fa-eye fa-1x"></i></a>
							</div>
						</div>
						<div class="text-center rounded-bottom p-4">
							<a href="#" class="d-block mb-2">SmartPhone</a> <a href="#"
								class="d-block h4">Apple iPad Mini <br> G2356
							</a>
							<del class="me-2 fs-5">$1,250.00</del>
							<span class="text-primary fs-5">$1,050.00</span>
						</div>
					</div>
					<div
						class="related-item-add border border-top-0 rounded-bottom  text-center p-4 pt-0">
						<a href="#"
							class="btn btn-primary border-secondary rounded-pill py-2 px-4 mb-4"><i
							class="fas fa-shopping-cart me-2"></i> Add To Cart</a>
						<div class="d-flex justify-content-between align-items-center">
							<div class="d-flex">
								<i class="fas fa-star text-primary"></i> <i
									class="fas fa-star text-primary"></i> <i
									class="fas fa-star text-primary"></i> <i
									class="fas fa-star text-primary"></i> <i class="fas fa-star"></i>
							</div>
							<div class="d-flex">
								<a href="#"
									class="text-primary d-flex align-items-center justify-content-center me-3"><span
									class="rounded-circle btn-sm-square border"><i
										class="fas fa-random"></i></i></a> <a href="#"
									class="text-primary d-flex align-items-center justify-content-center me-0"><span
									class="rounded-circle btn-sm-square border"><i
										class="fas fa-heart"></i></a>
							</div>
						</div>
					</div>
				</div>
				<div class="related-item rounded">
					<div class="related-item-inner border rounded">
						<div class="related-item-inner-item">
							<img src="${pageContext.request.contextPath}/img/product-3.png"
								class="img-fluid w-100 rounded-top" alt="">
							<div class="related-new">New</div>
							<div class="related-details">
								<a href="#"><i class="fa fa-eye fa-1x"></i></a>
							</div>
						</div>
						<div class="text-center rounded-bottom p-4">
							<a href="#" class="d-block mb-2">SmartPhone</a> <a href="#"
								class="d-block h4">Apple iPad Mini <br> G2356
							</a>
							<del class="me-2 fs-5">$1,250.00</del>
							<span class="text-primary fs-5">$1,050.00</span>
						</div>
					</div>
					<div
						class="related-item-add border border-top-0 rounded-bottom  text-center p-4 pt-0">
						<a href="#"
							class="btn btn-primary border-secondary rounded-pill py-2 px-4 mb-4"><i
							class="fas fa-shopping-cart me-2"></i> Add To Cart</a>
						<div class="d-flex justify-content-between align-items-center">
							<div class="d-flex">
								<i class="fas fa-star text-primary"></i> <i
									class="fas fa-star text-primary"></i> <i
									class="fas fa-star text-primary"></i> <i
									class="fas fa-star text-primary"></i> <i class="fas fa-star"></i>
							</div>
							<div class="d-flex">
								<a href="#"
									class="text-primary d-flex align-items-center justify-content-center me-3"><span
									class="rounded-circle btn-sm-square border"><i
										class="fas fa-random"></i></i></a> <a href="#"
									class="text-primary d-flex align-items-center justify-content-center me-0"><span
									class="rounded-circle btn-sm-square border"><i
										class="fas fa-heart"></i></a>
							</div>
						</div>
					</div>
				</div>
				<div class="related-item rounded">
					<div class="related-item-inner border rounded">
						<div class="related-item-inner-item">
							<img src="${pageContext.request.contextPath}/img/product-3.png"
								class="img-fluid w-100 rounded-top" alt="">
							<div class="related-new">New</div>
							<div class="related-details">
								<a href="#"><i class="fa fa-eye fa-1x"></i></a>
							</div>
						</div>
						<div class="text-center rounded-bottom p-4">
							<a href="#" class="d-block mb-2">SmartPhone</a> <a href="#"
								class="d-block h4">Apple iPad Mini <br> G2356
							</a>
							<del class="me-2 fs-5">$1,250.00</del>
							<span class="text-primary fs-5">$1,050.00</span>
						</div>
					</div>
					<div
						class="related-item-add border border-top-0 rounded-bottom  text-center p-4 pt-0">
						<a href="#"
							class="btn btn-primary border-secondary rounded-pill py-2 px-4 mb-4"><i
							class="fas fa-shopping-cart me-2"></i> Add To Cart</a>
						<div class="d-flex justify-content-between align-items-center">
							<div class="d-flex">
								<i class="fas fa-star text-primary"></i> <i
									class="fas fa-star text-primary"></i> <i
									class="fas fa-star text-primary"></i> <i
									class="fas fa-star text-primary"></i> <i class="fas fa-star"></i>
							</div>
							<div class="d-flex">
								<a href="#"
									class="text-primary d-flex align-items-center justify-content-center me-3"><span
									class="rounded-circle btn-sm-square border"><i
										class="fas fa-random"></i></i></a> <a href="#"
									class="text-primary d-flex align-items-center justify-content-center me-0"><span
									class="rounded-circle btn-sm-square border"><i
										class="fas fa-heart"></i></a>
							</div>
						</div>
					</div>
				</div>
				<div class="related-item rounded">
					<div class="related-item-inner border rounded">
						<div class="related-item-inner-item">
							<img src="${pageContext.request.contextPath}/img/product-3.png"
								class="img-fluid w-100 rounded-top" alt="">
							<div class="related-new">New</div>
							<div class="related-details">
								<a href="#"><i class="fa fa-eye fa-1x"></i></a>
							</div>
						</div>
						<div class="text-center rounded-bottom p-4">
							<a href="#" class="d-block mb-2">SmartPhone</a> <a href="#"
								class="d-block h4">Apple iPad Mini <br> G2356
							</a>
							<del class="me-2 fs-5">$1,250.00</del>
							<span class="text-primary fs-5">$1,050.00</span>
						</div>
					</div>
					<div
						class="related-item-add border border-top-0 rounded-bottom  text-center p-4 pt-0">
						<a href="#"
							class="btn btn-primary border-secondary rounded-pill py-2 px-4 mb-4"><i
							class="fas fa-shopping-cart me-2"></i> Add To Cart</a>
						<div class="d-flex justify-content-between align-items-center">
							<div class="d-flex">
								<i class="fas fa-star text-primary"></i> <i
									class="fas fa-star text-primary"></i> <i
									class="fas fa-star text-primary"></i> <i
									class="fas fa-star text-primary"></i> <i class="fas fa-star"></i>
							</div>
							<div class="d-flex">
								<a href="#"
									class="text-primary d-flex align-items-center justify-content-center me-3"><span
									class="rounded-circle btn-sm-square border"><i
										class="fas fa-random"></i></i></a> <a href="#"
									class="text-primary d-flex align-items-center justify-content-center me-0"><span
									class="rounded-circle btn-sm-square border"><i
										class="fas fa-heart"></i></a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- Related Product End -->

	<!-- Footer Start -->
	<div class="container-fluid footer py-5 wow fadeIn"
		data-wow-delay="0.2s">
		<div class="container py-5">
			<div class="row g-4 rounded mb-5"
				style="background: rgba(255, 255, 255, .03);">
				<div class="col-md-6 col-lg-6 col-xl-3">
					<div class="rounded p-4">
						<div
							class="rounded-circle bg-secondary d-flex align-items-center justify-content-center mb-4"
							style="width: 70px; height: 70px;">
							<i class="fas fa-map-marker-alt fa-2x text-primary"></i>
						</div>
						<div>
							<h4 class="text-white">Address</h4>
							<p class="mb-2">123 Street New York.USA</p>
						</div>
					</div>
				</div>
				<div class="col-md-6 col-lg-6 col-xl-3">
					<div class="rounded p-4">
						<div
							class="rounded-circle bg-secondary d-flex align-items-center justify-content-center mb-4"
							style="width: 70px; height: 70px;">
							<i class="fas fa-envelope fa-2x text-primary"></i>
						</div>
						<div>
							<h4 class="text-white">Mail Us</h4>
							<p class="mb-2">info@example.com</p>
						</div>
					</div>
				</div>
				<div class="col-md-6 col-lg-6 col-xl-3">
					<div class="rounded p-4">
						<div
							class="rounded-circle bg-secondary d-flex align-items-center justify-content-center mb-4"
							style="width: 70px; height: 70px;">
							<i class="fa fa-phone-alt fa-2x text-primary"></i>
						</div>
						<div>
							<h4 class="text-white">Telephone</h4>
							<p class="mb-2">(+012) 3456 7890</p>
						</div>
					</div>
				</div>
				<div class="col-md-6 col-lg-6 col-xl-3">
					<div class="rounded p-4">
						<div
							class="rounded-circle bg-secondary d-flex align-items-center justify-content-center mb-4"
							style="width: 70px; height: 70px;">
							<i class="fab fa-firefox-browser fa-2x text-primary"></i>
						</div>
						<div>
							<h4 class="text-white">Yoursite@ex.com</h4>
							<p class="mb-2">(+012) 3456 7890</p>
						</div>
					</div>
				</div>
			</div>
			<div class="row g-5">
				<div class="col-md-6 col-lg-6 col-xl-3">
					<div class="footer-item d-flex flex-column">
						<div class="footer-item">
							<h4 class="text-primary mb-4">Newsletter</h4>
							<p class="text-white mb-3">Dolor amet sit justo amet elitr
								clita ipsum elitr est.Lorem ipsum dolor sit amet, consectetur
								adipiscing elit consectetur adipiscing elit.</p>
							<div class="position-relative mx-auto rounded-pill">
								<input class="form-control rounded-pill w-100 py-3 ps-4 pe-5"
									type="text" placeholder="Enter your email">
								<button type="button"
									class="btn btn-primary rounded-pill position-absolute top-0 end-0 py-2 mt-2 me-2">SignUp</button>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-6 col-lg-6 col-xl-3">
					<div class="footer-item d-flex flex-column">
						<h4 class="text-primary mb-4">Customer Service</h4>
						<a href="#" class=""><i class="fas fa-angle-right me-2"></i>
							Contact Us</a> <a href="#" class=""><i
							class="fas fa-angle-right me-2"></i> Returns</a> <a href="#" class=""><i
							class="fas fa-angle-right me-2"></i> Order History</a> <a href="#"
							class=""><i class="fas fa-angle-right me-2"></i> Site Map</a> <a
							href="#" class=""><i class="fas fa-angle-right me-2"></i>
							Testimonials</a> <a href="#" class=""><i
							class="fas fa-angle-right me-2"></i> My Account</a> <a href="#"
							class=""><i class="fas fa-angle-right me-2"></i> Unsubscribe
							Notification</a>
					</div>
				</div>
				<div class="col-md-6 col-lg-6 col-xl-3">
					<div class="footer-item d-flex flex-column">
						<h4 class="text-primary mb-4">Information</h4>
						<a href="#" class=""><i class="fas fa-angle-right me-2"></i>
							About Us</a> <a href="#" class=""><i
							class="fas fa-angle-right me-2"></i> Delivery infomation</a> <a
							href="#" class=""><i class="fas fa-angle-right me-2"></i>
							Privacy Policy</a> <a href="#" class=""><i
							class="fas fa-angle-right me-2"></i> Terms & Conditions</a> <a
							href="#" class=""><i class="fas fa-angle-right me-2"></i>
							Warranty</a> <a href="#" class=""><i
							class="fas fa-angle-right me-2"></i> FAQ</a> <a href="#" class=""><i
							class="fas fa-angle-right me-2"></i> Seller Login</a>
					</div>
				</div>
				<div class="col-md-6 col-lg-6 col-xl-3">
					<div class="footer-item d-flex flex-column">
						<h4 class="text-primary mb-4">Extras</h4>
						<a href="#" class=""><i class="fas fa-angle-right me-2"></i>
							Brands</a> <a href="#" class=""><i
							class="fas fa-angle-right me-2"></i> Gift Vouchers</a> <a href="#"
							class=""><i class="fas fa-angle-right me-2"></i> Affiliates</a> <a
							href="#" class=""><i class="fas fa-angle-right me-2"></i>
							Wishlist</a> <a href="#" class=""><i
							class="fas fa-angle-right me-2"></i> Order History</a> <a href="#"
							class=""><i class="fas fa-angle-right me-2"></i> Track Your
							Order</a> <a href="#" class=""><i class="fas fa-angle-right me-2"></i>
							Track Your Order</a>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- Footer End -->


	<!-- Copyright Start -->
	<div class="container-fluid copyright py-4">
		<div class="container">
			<div class="row g-4 align-items-center">
				<div class="col-md-6 text-center text-md-start mb-md-0">
					<span class="text-white"><a href="#"
						class="border-bottom text-white"><i
							class="fas fa-copyright text-light me-2"></i>Your Site Name</a>, All
						right reserved.</span>
				</div>
				<div class="col-md-6 text-center text-md-end text-white">

					<!--/*** This template is free as long as you keep the below author’s credit link/attribution link/backlink. ***/-->
					<!--/*** If you'd like to use the template without the below author’s credit link/attribution link/backlink, ***/-->
					<!--/*** you can purchase the Credit Removal License from "https://htmlcodex.com/credit-removal". ***/-->
					Designed By <a class="border-bottom text-white"
						href="https://htmlcodex.com">HTML Codex</a>. Distributed By <a
						class="border-bottom text-white" href="https://themewagon.com">ThemeWagon</a>
				</div>
			</div>
		</div>
	</div>
	<!-- Copyright End -->


	<!-- Back to Top -->
	<a href="#" class="btn btn-primary btn-lg-square back-to-top"><i
		class="fa fa-arrow-up"></i></a>


	<!-- JavaScript Libraries -->
	<script
		src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
	<script
		src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
	<script src="${pageContext.request.contextPath}/lib/wow/wow.min.js"></script>
	<script
		src="${pageContext.request.contextPath}/lib/easing/easing.min.js"></script>
	<script
		src="${pageContext.request.contextPath}/lib/waypoints/waypoints.min.js"></script>
	<script
		src="${pageContext.request.contextPath}/lib/counterup/counterup.min.js"></script>
	<script
		src="${pageContext.request.contextPath}/lib/owlcarousel/owl.carousel.min.js"></script>
	<script
		src="${pageContext.request.contextPath}/lib/lightbox/js/lightbox.min.js"></script>


	<!-- Template Javascript -->
	<script src="${pageContext.request.contextPath}/js/main.js"></script>
</body>

</html>
