<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Register | Computer Space</title>
<base href="${pageContext.request.contextPath}/">
<link href="${pageContext.request.contextPath}/css/bootstrap.min.css"
	rel="stylesheet">
<link href="${pageContext.request.contextPath}/css/style.css"
	rel="stylesheet">
</head>
<body>
	<div class="container py-5">
		<h1>Register</h1>
		<form action="${pageContext.request.contextPath}/register"
			method="post">
			<div class="mb-3">
				<label class="form-label">Tên đăng nhập</label> <input type="text"
					name="username" class="form-control" required>
			</div>
			<div class="mb-3">
				<label class="form-label">Họ và tên</label> <input type="text"
					name="fullname" class="form-control" required>
			</div>
			<div class="mb-3">
				<label class="form-label">Email</label> <input type="email"
					name="email" class="form-control" required>
			</div>
			<div class="mb-3">
				<label class="form-label">Số điện thoại</label> <input type="text"
					name="phone" class="form-control" required>
			</div>
			<div class="mb-3">
				<label class="form-label">Mật khẩu</label> <input type="password"
					name="password" class="form-control" required>
			</div>
			<button type="submit" class="btn btn-primary">Đăng ký</button>
		</form>
		<p class="mt-3">
			Đã có tài khoản? <a href="${pageContext.request.contextPath}/login">Đăng
				nhập</a>
		</p>
		<p>
			<a href="${pageContext.request.contextPath}/home">Về trang chủ</a>
		</p>
	</div>
</body>
</html>
