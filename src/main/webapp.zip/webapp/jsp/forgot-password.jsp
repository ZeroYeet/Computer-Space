<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Quên mật khẩu | Computer Space</title>
<base href="${pageContext.request.contextPath}/">
<link href="${pageContext.request.contextPath}/css/bootstrap.min.css"
	rel="stylesheet">
<link href="${pageContext.request.contextPath}/css/style.css"
	rel="stylesheet">
</head>
<body>
	<div class="container py-5">
		<h1>Quên mật khẩu</h1>
		<form action="${pageContext.request.contextPath}/forgot-password"
			method="post">
			<div class="mb-3">
				<label class="form-label">Email</label> <input type="email"
					name="email" class="form-control" required>
			</div>
			<button type="submit" class="btn btn-primary">Gửi yêu cầu</button>
		</form>
		<p class="mt-3">
			<a href="${pageContext.request.contextPath}/login">Quay lại đăng
				nhập</a>
		</p>
		<p>
			<a href="${pageContext.request.contextPath}/home">Về trang chủ</a>
		</p>
	</div>
</body>
</html>
