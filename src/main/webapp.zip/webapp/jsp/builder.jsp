<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>PC Builder | Computer Space</title>
<base href="${pageContext.request.contextPath}/">
<link href="${pageContext.request.contextPath}/css/bootstrap.min.css"
	rel="stylesheet">
<link href="${pageContext.request.contextPath}/css/style.css"
	rel="stylesheet">
</head>
<body>
	<div class="container py-5">
		<h1>PC Builder</h1>
		<p>Chức năng cấu hình PC đang được tích hợp vào hệ thống. Bạn có
			thể thêm cấu hình vào giỏ hàng khi đăng nhập.</p>
		<p>
			<a href="${pageContext.request.contextPath}/home">Về trang chủ</a>
		</p>
	</div>
</body>
</html>
