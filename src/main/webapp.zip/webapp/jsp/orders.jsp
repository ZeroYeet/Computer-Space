<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Orders | Computer Space</title>
<base href="${pageContext.request.contextPath}/">
<link href="${pageContext.request.contextPath}/css/bootstrap.min.css"
	rel="stylesheet">
<link href="${pageContext.request.contextPath}/css/style.css"
	rel="stylesheet">
</head>
<body>
	<div class="container py-5">
		<h1>Orders</h1>
		<p>Danh sách đơn hàng của bạn sẽ hiển thị tại đây sau khi đăng
			nhập.</p>
		<p>
			<a href="${pageContext.request.contextPath}/home">Về trang chủ</a>
		</p>
	</div>
</body>
</html>
