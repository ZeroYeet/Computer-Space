<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Admin Accounts</title>
<base href="${pageContext.request.contextPath}/">
<link href="${pageContext.request.contextPath}/css/bootstrap.min.css"
	rel="stylesheet">
<link href="${pageContext.request.contextPath}/css/style.css"
	rel="stylesheet">
</head>
<body>
	<div class="container py-5">
		<h1>Admin Accounts</h1>
		<p>Quản lý tài khoản admin sẽ hiển thị ở đây.</p>
		<p>
			<a href="${pageContext.request.contextPath}/admin/dashboard">Quay
				lại dashboard</a>
		</p>
	</div>
</body>
</html>
